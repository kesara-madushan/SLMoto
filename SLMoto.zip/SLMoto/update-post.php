<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="./css/post-vehicle.css">
    <script src="./javascript/post-vehicle.js"></script>
</head>

<body>

    <?php

    include "navbar-owner.php";

    $post_id = $_GET["id"];

    $image1 = $image2 = $image3 = $make = $model = $year = $type = $ratePerDay = $ratePerWeek = $ratePerMonth = $description = "";

    $image1Err = $image2Err = $image3Err = $makeErr = $modelErr = $yearErr = $ratePerDayErr = $ratePerWeekErr = $ratePerMonthErr = $descriptionErr = "";

    function test_input($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars_decode($data);

        return $data;
    }

    function convertToBase64($imageSlot)
    {
        $img_path = $_FILES[$imageSlot]['tmp_name'];
        $img_name = $_FILES[$imageSlot]['name'];
        $type = pathinfo($img_name, PATHINFO_EXTENSION);
        $img_data = file_get_contents($img_path);

        $base64_code = base64_encode($img_data);
        $base64_str = 'data:image/' . $type . ';base64,' . $base64_code;

        return $base64_str;
    }

    $servername = "localhost";
    $username = "root";
    $dbpassword = "";
    $dbname = "slmoto";

    // Create connection
    $conn = new mysqli($servername, $username, $dbpassword, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM posts WHERE post_id={$post_id}";

    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $post = $result->fetch_assoc();

        $image1 = $post["image_1"];
        $image2 = $post["image_2"];
        $image3 = $post["image_3"];
        $make = $post["make"];
        $model = $post["model"];
        $year = $post["year"];
        $type = $post["type"];
        $ratePerDay = $post["rate_per_day"];
        $ratePerWeek = $post["rate_per_week"];
        $ratePerMonth = $post["rate_per_month"];
        $description = $post["description"];
    }


    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        // Validate make
        if (empty($_POST["make"])) {
            $makeErr = "Required";
        } else {
            $make = test_input($_POST["make"]);
            $makeErr = "";
            if (strlen($make) > 15) {
                $makeErr = "Max 15 characters";
            }
        }

        // Validate model
        if (empty($_POST["model"])) {
            $modelErr = "Required";
        } else {
            $model = test_input($_POST["model"]);
            $modelErr = "";
            if (strlen($model) > 15) {
                $modelErr = "Max 15 characters";
            }
        }

        // Validate year 
        if (empty($_POST["year"])) {
            $yearErr = "Required";
        } else {
            $year = test_input($_POST["year"]);
            $yearErr = "";
            if ($year < 1990 || $year > date("Y")) {
                $yearErr = "1990 to " . date("Y");
            }
            if (!preg_match("/^[0-9 ]*$/", $year)) {
                $yearErr = "Only numbers";
            }
        }

        // Validate rates
        if (empty($_POST["per-day"])) {
            $ratePerDayErr = "Required";
        } else {
            $ratePerDay = $_POST["per-day"];
            $ratePerDayErr = "";
            if (!preg_match("/^[0-9 ]*$/", $ratePerDay)) {
                $ratePerDayErr = "Only numbers";
            }
        }
        if (empty($_POST["per-week"])) {
            $ratePerWeekErr = "Required";
        } else {
            $ratePerWeek = $_POST["per-week"];
            $ratePerWeekErr = "";
            if (!preg_match("/^[0-9 ]*$/", $ratePerWeek)) {
                $ratePerWeekErr = "Only numbers";
            }
        }
        if (empty($_POST["per-month"])) {
            $ratePerMonthErr = "Required";
        } else {
            $ratePerMonth = $_POST["per-month"];
            $ratePerMonthErr = "";
            if (!preg_match("/^[0-9 ]*$/", $ratePerMonth)) {
                $ratePerMonthErr = "Only numbers";
            }
        }

        $description = test_input($_POST["description"]);
        $type = $_POST["type"];

        if (!empty($_FILES["image1"]["name"])) {
            $image1 = convertToBase64("image1");
        } 

        if (!empty($_FILES["image2"]["name"])) {
            $image2 = convertToBase64("image2");
        } 

        if (!empty($_FILES["image3"]["name"])) {
            $image3 = convertToBase64("image3");
        } 
    }


    if (isset($_POST["update"])) {

        if ($makeErr == "" && $modelErr == "" && $yearErr == "" && $ratePerDayErr == "" && $ratePerWeekErr == "" && $ratePerMonthErr == "") {
    
    
    
            // $sql = "INSERT INTO posts (make, model , year, type, rate_per_day, rate_per_week, rate_per_month, description, 
            //         image_1, image_2, image_3) VALUES ('{$make}', '{$model}', {$year}, '{$type}', {$ratePerDay}, 
            //         {$ratePerWeek},{$ratePerMonth},'{$description}','{$image1}', '{$image2}', '{$image3}');";
    
            $sql = "UPDATE posts SET make='{$make}', model='{$model}', year={$year}, type='{$type}', rate_per_day={$ratePerDay}, 
            rate_per_week={$ratePerWeek}, rate_per_month={$ratePerMonth}, description='{$description}', image_1='{$image1}',
            image_2='{$image2}', image_3='{$image3}' WHERE post_id=$post_id;";
    
    
            if ($conn->query($sql) === TRUE) {
                echo "Post updated successfully";
    
                header("Location:my-vehicles.php");
            } else {
                echo "Error" . $sql . "<br>" . $conn->error;
            }
            $conn->close();
        }
    }

    function deletePost($post_id, $conn){
        echo "Hi !";
        // $sql_del = "DELETE FROM posts WHERE post_id={$post_id};";

        // if ($conn->query($sql_del) === TRUE) {
        //     echo "Post deleted successfully";

        //     header("Location:my-vehicles.php");
        // } else {
        //     echo "Error" . $sql_del . "<br>" . $conn->error;
        // }
        // $conn->close();

    }


    ?>




    <div id="post-ad">

        <h2>Update your advertisement</h2>

        <form action="index.php?page=update-post&id=<?= $post_id ?>" method="POST" enctype="multipart/form-data">

            <label for="images">Images</label>
            <input type="file" id="image1" class="image-selecter" name="image1" value="Image 1" accept="image/gif, image/jpeg, image/png, image/jpg" onchange="loadFile(event, 'output1')">
            <input type="file" id="image2" class="image-selecter" name="image2" value="Image 1" accept="image/gif, image/jpeg, image/png, image/jpg" onchange="loadFile(event, 'output2')">
            <input type="file" id="image3" class="image-selecter" name="image3" value="Image 1" accept="image/gif, image/jpeg, image/png, image/jpg" onchange="loadFile(event, 'output3')"><br>

            <table style="width: 100%;">
                <tr>
                    <th>Image 1</th>
                    <th>Image 2</th>
                    <th>Image 3</th>
                </tr>
                <tr>
                    <td><img id="output1" src="<?php echo $image1 ?>" alt="image" style="width: 250px; height: 188px;"></td>
                    <td><img id="output2" src="<?php echo $image2 ?>" alt="image" style="width: 250px; height: 188px;"></td>
                    <td><img id="output3" src="<?php echo $image3 ?>" alt="image" style="width: 250px; height: 188px;"></td>
                </tr>
            </table>




            <table style="width: 100%;">
                <tr>
                    <td>
                        <label for="make">Make</label> <span class="error" style="color = red;">* <?php echo $makeErr; ?></span><br>
                        <input type="text" id="make" class="text-inputs" name="make" value="<?php echo $make; ?>">
                    </td>
                    <td>
                        <lable for="model">Model</lable> <span class="error" style="color = red;">* <?php echo $modelErr; ?></span><br>
                        <input type="text" id="model" class="text-inputs" name="model" value="<?php echo $model; ?>">
                    </td>
                </tr>

                <tr>
                    <td>
                        <label for="year">Year</label> <span class="error" style="color = red;">* <?php echo $yearErr; ?></span><br>
                        <input type="number" id="year" class="text-inputs" name="year" value="2020" value="<?php echo $year; ?>">
                    </td>
                    <td>
                        <label for="type">Type</label><br>
                        <select id="type" class="text-inputs" name="type" value="<?php echo $type; ?>">
                            <option value="Car">Car</option>
                            <option value="Van">Van</option>
                        </select>
                    </td>
                </tr>

                <tr>
                    <td>
                        <label for="per-day">Rate per day</label><span class="error" style="color = red;">* <?php echo $ratePerDayErr; ?></span><br>
                        <input type="text" id="per-day" class="text-inputs" name="per-day" value="<?php echo $ratePerDay; ?>">
                    </td>
                    <td>
                        <label for="per-week">Rate per week</label> <span class="error" style="color = red;">* <?php echo $ratePerWeekErr; ?></span><br>
                        <input type="text" id="per-week" class="text-inputs" name="per-week" value="<?php echo $ratePerWeek; ?>">
                    </td>
                </tr>

                <tr>
                    <td>
                        <label for="per-month">Rate per month</label> <span class="error" style="color = red;">* <?php echo $ratePerMonthErr; ?></span><br>
                        <input type="text" id="per-month" class="text-inputs" name="per-month" value="<?php echo $ratePerMonth; ?>">
                    </td>
                    <td></td>
                </tr>

            </table>
            <br>
            <label for="description">Description</label><br>
            <textarea id="decription" class="text-inputs" name="description" rows="4" cols="50" style="width: 90%;" ><?php echo $description; ?></textarea>

            <div id="buttons">

                <button type="button" class="button" style="background-color: indianred; opacity:100%;" 
                onclick="let confirmation = confirm('Are you sure you want to delete this post?'); if(confirmation){document.getElementById('delete').innerHTML = '<?php deletePost($post_id, $conn); ?>'}">Delete</button>
                
                <!-- <button type="button" id="reset-button" name="delete" class="button" style="background-color: indianred; opacity:100%;" 
                value="Delete" onclick="confirmDelete()" >Delete</button> -->
                <input type="submit" id="submit-button" name="update" class="button" style="background-color: dodgerblue; opacity:100%;" value="Update">
            </div>

            <div id="delete"></div>

        </form>

    </div>



</body>

</html>

