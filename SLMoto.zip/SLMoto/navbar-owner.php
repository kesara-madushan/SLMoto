<!DOCTYPE html>
<html>
    <head>
    <link rel="stylesheet" href="./css/home.css">
    </head>

    <body>
    
        <div class="topnav">
            <a class="active" href="home-owner.php" >Home</a>
            <a href="index.php?page=my-vehicles">My Vehicles</a>
            <a href="#Contact">Contact</a>
            <a href="#about">About</a>
            <p style="color: white;">SLMoto</p>
        </div>

    </body>
</html>