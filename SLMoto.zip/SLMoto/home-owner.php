<?php 

session_start();



?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="./css/home.css">
        <!-- <script src="register-user.js"></script> -->
    </head>

    <body style="background-color: black;">

        <?php include "navbar-owner.php" ?>

    <img src="./images/home.jpg" style="width: 100%;">

    <div class="login">
        <div style="font-size: 28px;"><b>Login as</b></div>
        <button class="login-buttons"><a id="user-login" class="login-buttons" href="login-user.php">Customer</a></button>
        <button class="login-buttons"><a id="owner-login" class="login-buttons" href="login-owner.php">Vehicle Owner</a></button>
        <button class="login-buttons"><a id="admin-login" class="login-buttons" href="login-user.php">Admin</a></button><br>
        <button class="login-buttons"><a id="user-login" class="login-buttons" href="logout.php">Logout</a></button>
       
        
        
    </div>

    </body>
</html>