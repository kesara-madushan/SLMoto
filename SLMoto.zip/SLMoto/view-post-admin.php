<?php

session_start();

include "navbar-admin.php";

if (isset($_GET["id"])) {

    $post_id = $_GET["id"];

    $servername = "localhost";
    $username = "root";
    $dbpassword = "";
    $dbname = "slmoto";

    // Create connection
    $conn = new mysqli($servername, $username, $dbpassword, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM posts WHERE post_id=$post_id;";

    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $post = $result->fetch_assoc();


?>


        <!DOCTYPE html>
        <html>

        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="./css/view-post.css">

        </head>

        <body>


            <div class="row">
                <div class="column">
                    <div class="slideshow-container">

                        <div class="mySlides fade">
                            <div class="numbertext">1 / 3</div>
                            <img src="<?php echo $post["image_1"]; ?>" style="width:100%">
                            <div class="text">Caption Text</div>
                        </div>

                        <div class="mySlides fade">
                            <div class="numbertext">2 / 3</div>
                            <img src="<?php echo $post["image_2"]; ?>" style="width:100%">
                            <div class="text">Caption Two</div>
                        </div>

                        <div class="mySlides fade">
                            <div class="numbertext">3 / 3</div>
                            <img src="<?php echo $post["image_3"] ?>" style="width:100%">
                            <div class="text">Caption Three</div>
                        </div>

                        <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
                        <a class="next" onclick="plusSlides(1)">&#10095;</a>

                    </div>
                    <br>

                    <div style="text-align:center">
                        <span class="dot" onclick="currentSlide(1)"></span>
                        <span class="dot" onclick="currentSlide(2)"></span>
                        <span class="dot" onclick="currentSlide(3)"></span>
                    </div>


                </div>
                <div class="column">

                    <div class="details">
                        <h2 style="color: white; background-color:darkblue; padding:10px; border-radius:10px;">
                            <b><?php echo $post["make"] . " " . $post["model"] . " " . $post["year"]; ?></b>
                        </h2>

                        <table class="details-table">
                            <tr>
                                <td><b>Make</b> </td>
                                <td><?php echo $post["make"]; ?></td>
                            </tr>
                            <tr>
                                <td><b>Model</b> </td>
                                <td><?php echo $post["model"]; ?></td>
                            </tr>
                            <tr>
                                <td><b>Type</b> </td>
                                <td><?php echo $post["type"]; ?></td>
                            </tr>
                            <tr>
                                <td><b>Rate per Day</b> </td>
                                <td><?php echo $post["rate_per_day"] . "/-  LKR"; ?></td>
                            </tr>
                            <tr>
                                <td><b>Rate per Week</b> </td>
                                <td><?php echo $post["rate_per_week"] . "/-  LKR"; ?></td>
                            </tr>
                            <tr>
                                <td><b>Rate per Month</b> </td>
                                <td><?php echo $post["rate_per_month"] . "/-  LKR"; ?></td>
                            </tr>
                            <tr>
                                <td><b>Description</b> </td>
                                <td><?php echo $post["description"]; ?></td>
                            </tr>

                        </table>

                        <h3 style="color: white; background-color:firebrick; padding:10px; border-radius:10px;">
                            <b>Owner</b>
                        </h3>
                        <?php

                        $sql_owner = "SELECT * FROM owners WHERE owner_id={$post["owner_id"]};";
                        $result_owner = $conn->query($sql_owner);

                        if ($result_owner->num_rows == 1) {
                            $owner = $result_owner->fetch_assoc();

                        ?>

                            <table class="details-table">
                                <tr>
                                    <td><b>Name</b> </td>
                                    <td><?php echo $owner["first_name"] . " " . $owner["last_name"] ; ?></td>
                                </tr>
                                <tr>
                                    <td><b>Gender</b> </td>
                                    <td><?php echo $owner["gender"]; ?></td>
                                </tr>
                                <tr>
                                    <td><b>Telephone</b> </td>
                                    <td><?php echo $owner["telephone"]; ?></td>
                                </tr>
                                <tr>
                                    <td><b>Email</b> </td>
                                    <td><?php echo $owner["email"]; ?></td>
                                </tr>
                                <tr>
                                    <td><b>Address</b> </td>
                                    <td><?php echo $owner["address"] ?></td>
                                </tr>
                                

                            </table>


                    </div>

                </div>
            </div>


            <script src="./javascript/view-post.js"></script>

        </body>

        </html>


<?php
                        }
                    }
                }

                echo "<script> if(window.history.replaceState) {
    window.history.replaceState(null,null,window.location.href);
}</script>";
?>