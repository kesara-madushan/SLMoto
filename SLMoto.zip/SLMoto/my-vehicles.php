<?php

session_start();



$owner_id = $_SESSION["user_id"];



?>

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="./css/all-vehicles.css">
    <script src="./javascript/"></script>
</head>

<body>

    <?php include "navbar-owner.php"; ?>

    <div class="row">
    <div style="margin: 0 30px 0 0;">
    <a href="post-vehicle.php">
        <button id="add-new-post" style="float: left; padding:10px 40px; margin:0 0 0 30px; border:none; background-color:limegreen; color:white; font-size:large;"><b>Add New Vehicle</b></button>
    </a>
        <a href="./update-owner.php" style="float: right; color:blue;">Update your profile</a>
        <label style="float: right; color:mediumseagreen; margin-right: 20px;"><b>Hi <?php echo $_SESSION["user_name"] ?></b></label>
    </div>
    </div>


    


    <div class="row">


        <?php


        $servername = "localhost";
        $username = "root";
        $dbpassword = "";
        $dbname = "slmoto";

        // Create connection
        $conn = new mysqli($servername, $username, $dbpassword, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT * FROM posts WHERE owner_id={$owner_id};";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {

            //Output and display data from each row
            while ($row = $result->fetch_assoc()) {

        ?>


                <div class="column">
                    <div class="card">

                        <img src="<?php echo $row["image_1"]; ?>" alt="car-image" style="width: 100%;">
                        <h3><b><?php echo $row["make"] . " " . $row["model"] . " " . $row["year"]; ?></b></h3>
                        <p class="price"><?php echo $row["rate_per_day"]; ?> LKR per day</p>
                        <a href="index.php?page=update-post&id=<?= $row["post_id"] ?>">
                            <p><button type="button" name="button">Update Post</button></p>
                        </a>

                    </div>
                </div>

        <?php
            }
        }

        ?>

    </div>


</body>

</html>