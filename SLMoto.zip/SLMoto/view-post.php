<?php

session_start();

include "navbar.php";
if (isset($_GET["id"])) {

    $post_id = $_GET["id"];

    $servername = "localhost";
    $username = "root";
    $dbpassword = "";
    $dbname = "slmoto";

    // Create connection
    $conn = new mysqli($servername, $username, $dbpassword, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM posts WHERE post_id=$post_id;";

    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $post = $result->fetch_assoc();


        $from = $to = "";
        $fromErr = $toErr = "";
        if ($_SERVER["REQUEST_METHOD"] == "POST") {


            if (empty($_POST["from"])) {
                $fromErr = "Starting date required";
            } else {
                $from = str_replace("T"," ",$_POST["from"]) . ":00" ;
                $fromErr = "";
            }

            if (empty($_POST["to"])) {
                $toErr = "Returning date required";
            } else {
                $to = str_replace("T"," ",$_POST["to"]) . ":00";
                $toErr = "";
            }
        }


        if (isset($_POST["submit"])) {

            if ($fromErr == "" && $toErr == "") {
                echo $_SESSION["user_id"];

                if ($_SESSION["user_id"] == 0) {
                    $_SESSION["return_to"] = $post_id;
                    header("Location:login-user.php");
                } else {
                    $sql = "INSERT INTO reservations (client_id, post_id, date_from, date_to) 
                            VALUES ({$_SESSION["user_id"]},{$post_id},'{$from}','{$to}');";

                    if ($conn->query($sql) === TRUE) {
                        echo "Reservation request added successfully";

                        header("Location:all-vehicles.php");
                    } else {
                        echo "Error" . $sql . "<br>" . $conn->error;
                    }
                }
            }
        }

?>


        <!DOCTYPE html>
        <html>

        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="./css/view-post.css">

        </head>

        <body>


            <div class="row">
                <div class="column">
                    <div class="slideshow-container">

                        <div class="mySlides fade">
                            <div class="numbertext">1 / 3</div>
                            <img src="<?php echo $post["image_1"]; ?>" style="width:100%">
                            <div class="text">Caption Text</div>
                        </div>

                        <div class="mySlides fade">
                            <div class="numbertext">2 / 3</div>
                            <img src="<?php echo $post["image_2"]; ?>" style="width:100%">
                            <div class="text">Caption Two</div>
                        </div>

                        <div class="mySlides fade">
                            <div class="numbertext">3 / 3</div>
                            <img src="<?php echo $post["image_3"] ?>" style="width:100%">
                            <div class="text">Caption Three</div>
                        </div>

                        <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
                        <a class="next" onclick="plusSlides(1)">&#10095;</a>

                    </div>
                    <br>

                    <div style="text-align:center">
                        <span class="dot" onclick="currentSlide(1)"></span>
                        <span class="dot" onclick="currentSlide(2)"></span>
                        <span class="dot" onclick="currentSlide(3)"></span>
                    </div>


                </div>
                <div class="column">

                    <div class="details">
                        <h2 style="color: white; background-color:darkblue; padding:10px; border-radius:10px;">
                            <b><?php echo $post["make"] . " " . $post["model"] . " " . $post["year"]; ?></b>
                        </h2>

                        <table class="details-table">
                            <tr>
                                <td><b>Make</b> </td>
                                <td><?php echo $post["make"]; ?></td>
                            </tr>
                            <tr>
                                <td><b>Model</b> </td>
                                <td><?php echo $post["model"]; ?></td>
                            </tr>
                            <tr>
                                <td><b>Type</b> </td>
                                <td><?php echo $post["type"]; ?></td>
                            </tr>
                            <tr>
                                <td><b>Rate per Day</b> </td>
                                <td><?php echo $post["rate_per_day"] . "/-  LKR"; ?></td>
                            </tr>
                            <tr>
                                <td><b>Rate per Week</b> </td>
                                <td><?php echo $post["rate_per_week"] . "/-  LKR"; ?></td>
                            </tr>
                            <tr>
                                <td><b>Rate per Month</b> </td>
                                <td><?php echo $post["rate_per_month"] . "/-  LKR"; ?></td>
                            </tr>
                            <tr>
                                <td><b>Description</b> </td>
                                <td><?php echo $post["description"]; ?></td>
                            </tr>

                        </table>

                        <h3 style="color: white; background-color:firebrick; padding:10px; border-radius:10px;">
                            <b>Reserve</b>
                        </h3>


                        <div id="form-container">
                            <form action="index.php?page=view-post&id=<?= $post_id ?>" method="POST">

                                <table class="reserve-table">
                                    <tr>
                                        <td><b>From</b></td>
                                        <td>
                                            <input type="datetime-local" name="from" class="inputs" value="<?php echo $from; ?>" style=" padding:5px; border-radius: 10px;">
                                            <span style="color: red;">* <?php echo $fromErr; ?></span>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td><b>To</b></td>
                                        <td>
                                            <input type="datetime-local" name="to" class="inputs" value="<?php echo $from; ?>" style=" padding:5px; border-radius: 10px;">
                                            <span style="color: red;">* <?php echo $toErr; ?></span>
                                        </td>

                                    </tr>
                                </table>
                                <input type="submit" value="Submit" name="submit" style="color:white; background-color:mediumseagreen; padding:5px; width:100%; border-radius:10px; font-size:large;">
                            </form>
                        </div>
                    </div>

                </div>
            </div>


            <script src="./javascript/view-post.js"></script>

        </body>

        </html>


<?php

    }
}

echo "<script> if(window.history.replaceState) {
    window.history.replaceState(null,null,window.location.href);
}</script>";
?>