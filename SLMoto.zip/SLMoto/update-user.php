<?php
    include "navbar.php";

    session_start();

    $user_id = $_SESSION["user_id"];
?>


<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="./css/register-user.css">
        <script src="./javascript/register-user.js"></script>
    </head>
    <body>


    <?php

$fnameErr = $lnameErr = $genderErr = $telephoneErr = $emailErr = $addressErr = $passwordErr =  $confirmPasswordErr = "";

$fname = $lname = $gender = $telephone = $email = $address = $password = $confirmPassword = "";


function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars_decode($data);

    return $data;
}

$servername = "localhost";
$username = "root";
$dbpassword = "";
$dbname = "slmoto";

// Create connection
$conn = new mysqli($servername,$username,$dbpassword,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: ". $conn->connect_error);
}

$sql = "SELECT * FROM clients WHERE client_id={$user_id};";

$result = $conn->query($sql);

if ($result->num_rows == 1) {
    $user = $result->fetch_assoc();

    $fname = $user["first_name"];
    $lname = $user["last_name"];
    $gender = $user["gender"];
    $telephone = $user["telephone"];
    $email = $user["email"];
    $address = $user["address"];
    $password = $confirmPassword = $user["password"];
    
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validate first name
    if (empty($_POST["fname"])) {
        $fnameErr = "First name is required";
    } else {
        $fname = test_input($_POST["fname"]);
        $fnameErr = "";
        
        if (!preg_match("/^[a-zA-Z-' ]*$/", $fname)){
            $fnameErr = "Only alphabets and white spaces are allowed";
        }
    }   

    // Validate last name
    if (empty($_POST["lname"])) {
        $lnameErr = "Last name is required";
    } else {
        $lname = test_input($_POST["lname"]);
        $lnameErr = "";
        
        if (!preg_match("/^[a-zA-Z-' ]*$/", $lname)){
            $lnameErr = "Only alphabets and white spaces are allowed";
        }
    }  
    
    // Validate gender
    if (empty($_POST["gender"])) {
        $genderErr = "Gender is required";
    } else {
        $gender = test_input($_POST["gender"]);
        $genderErr = "";
    }

    // Validate telephone 
    if (empty($_POST["telephone"])) {
        $telephoneErr = "Telephone number is required";
    } else {
        $telephone = test_input($_POST["telephone"]);
        $telephoneErr = "";

        if (!preg_match("/^[0-9 ]*$/", $telephone)) {
            $telephoneErr = "Only numbers are allowed";
        }
        if ( strlen($telephone) != 10) {
            $telephoneErr = "Telephone number must contain 10 digits";
        }
    }

    // Validate email
    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
    } else {
        $email = test_input($_POST["email"]);
        $emailErr = "";

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
        }
    }

    // Validate address
    if (empty($_POST["address"])) {
        $addressErr = "Address is required";
    } else {
        $address = $_POST["address"];
        $addressErr = "";
    }

    // Validate passwords
    if (empty($_POST["password"])) {
        $passwordErr = "Password is required";
    } else {
        $password = $_POST["password"];
        $passwordErr = "";
        if ( strlen($password) > 15  ) {
            $passwordErr = "Maximum 15 characters are allowed";
            $password = $confirmPassword = "";
                }
        if (strlen($password)<6) {
            $passwordErr = "Minimum 6 characters required";
            $password = $confirmPassword = "";
        }
    }

    if (empty($_POST["confirm-password"])) {
        $confirmPasswordErr = "Password confirmation is required";
        $password = $confirmPassword = "";
    } else {
        $confirmPassword = $_POST["confirm-password"];
        $confirmPasswordErr = "";
    }

    if ($password != $confirmPassword ){
        $confirmPasswordErr = "Two passwords are not matching";
        $password = $confirmPassword = "";
    }

}

if (isset($_POST["submit"])) {
    if($fnameErr == "" && $lnameErr == "" && $genderErr == "" && $telephoneErr == "" && $emailErr == ""
     && $addressErr == "" && $passwordErr == "" && $confirmPasswordErr == "") {
           
 
            $sql = "UPDATE clients SET first_name='{$fname}', last_name='{$lname}', gender='{$gender}', 
            telephone='{$telephone}', email='{$email}', address='{$address}', password='{$password}' WHERE client_id={$user_id};";
            
            
            if ($conn->query($sql)===TRUE) {
                echo "User details updated successfully";
                session_unset();
                session_destroy();
                header("Location:login-user.php");
            } else {
                echo "Error" . $sql . "<br>" . $conn->error;
            }
            $conn->close();

        }
}


?>
        
        <div id="sign-up">
            <h2>Update your details</h2>
            <div>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                    <label for="fname">First name </label>
                    <span class="error" style="color = red;">* <?php echo $fnameErr; ?></span>
                    <input type="text" id="fname" name="fname" class="txt-inputs" value="<?php echo $fname; ?>">
        
                    <label for="lname">Last name  </label>
                    <span class="error">* <?php echo $lnameErr; ?></span>
                    <input type="text" id="lname" name="lname" class="txt-inputs" value="<?php echo $lname; ?>">

                    <label for="gender">Gender</label>
                    <span class="error">* <?php echo $genderErr; ?></span><br>

                    <input type="radio" id="gender" name="gender" <?php if(isset($gender) && $gender=="Male") echo "checked"; ?> value="Male" class="radio">
                    <label>Male</label>
                    <input type="radio" id="gender" name="gender" <?php if(isset($gender) && $gender=="Female") echo "checked"; ?> value="Female" class="radio" >
                    <label>Female</label>
                    <br>

                    <label for="telephone">Telephone  </label>
                    <span class="error">* <?php echo $telephoneErr; ?></span>
                    <input type="tel" id="telephone" name="telephone" class="txt-inputs" value="<?php echo $telephone; ?>">
        
                    <label for="email">Email  </label>
                    <span class="error">* <?php echo $emailErr; ?></span>
                    <input type="email" id="email" name="email" class="txt-inputs" value="<?php echo $email; ?>">
    
                    <label for="address">Address </label>
                    <span class="error">* <?php echo $addressErr; ?></span>
                    <input type="text" id="address" name="address" class="txt-inputs" value="<?php echo $address; ?>">

                    <label for="password">Password  </label>
                    <span class="error">* <?php echo $passwordErr; ?></span>
                    <input type="password" id="password" name="password" class="txt-inputs" value="<?php echo $password; ?>">
    
                    <label for="confirm-password">Confirm password </label>
                    <span class="error">* <?php echo $confirmPasswordErr; ?></span>
                    <input type="password" id="confirm-password" name="confirm-password" class="txt-inputs" value="<?php echo $confirmPassword; ?>">

                    <div id="buttons">
                        <input type="submit" id="submit-button" name="submit" class="button" value="Update" style="background-color: dodgerblue;">
                    </div>
                    
                    
                </form>
            </div>           
        </div>

        
    </body>
</html>


<?php



    echo "<script> if(window.history.replaceState) {
        window.history.replaceState(null,null,window.location.href);
    }</script>";


?>

