function clearFields(){
    document.getElementById("email").innerHTML="";
   
    document.getElementById("password").innerHTML="";

    alert("All fields will be cleared!");
}

