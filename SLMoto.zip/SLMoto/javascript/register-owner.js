
function test(){
    document.getElementById("fname").innerHTML="";
    document.getElementById("lname").innerHTML="";
    document.getElementById("telephone").innerHTML="";
    document.getElementById("email").innerHTML="";
    document.getElementById("address").innerHTML="";

    alert("All fields will be cleared!");
}

function clearState(){
    if(window.history.replaceState) {
        window.history.replaceState(null,null,window.location.href);
    }
}