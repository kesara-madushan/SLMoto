
var loadFile = function(event, id) {
    var image = document.getElementById(id);
    image.src = URL.createObjectURL(event.target.files[0]);
};


function readURL(input) {
    if(input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#blah')
                .attr('src', e.target.result)
                .width(150)
                .height(200);
        };
        reader.readAsDataURL(input.files[0]);
    }
}

function confirmDelete() {

    let confirmDelete = confirm("Are you sure you want to delete this post ?");
    if(confirmDelete) {
        alert("Post successfully deleted !");
        document.write("<?php deletePost($post_id, $conn); header('Location:my-vehicles.php');?>");  
    }
}