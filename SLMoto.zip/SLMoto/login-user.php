<?php
    session_start();

?>



<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="./css/login-user.css"> 
        <script src="./javascript/login-user.js"></script>
    </head>

    <body>

<?php

include "navbar.php";

$email = $password = "";
$emailErr = $passwordErr = "";

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars_decode($data);

    return $data;
}


if ($_SERVER["REQUEST_METHOD"] == "POST"){

    // Validate email
    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
        $email = $password = "";
    } else {
        $email = test_input($_POST["email"]);
        $emailErr = "";

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
            $email = $password = "";
        }
    }

     // Validate passwords
     if (empty($_POST["password"])) {
        $passwordErr = "Password is required";
    } else {
        $password = $_POST["password"];
        $passwordErr = "";
        if ( strlen($password) > 15  ) {
            $passwordErr = "Maximum 15 characters are allowed";
            $password =  "";
                }
        if (strlen($password)<6) {
            $passwordErr = "Minimum 6 characters required";
            $password =  "";
        }
    }

}

    

?>


        <div id="login">
            <h2>Login</h2>

            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" >
                <span class="error" style="color = red;"> <?php echo $emailErr; ?></span><br>
                <input type="text" placeholder="Email address" name="email" id="email" class="txt" value="<?php echo $email ?>">

                <span class="error" style="color = red;"> <?php echo $passwordErr; ?></span><br>
                <input type="password" placeholder="Password" name="password" id="password" class="txt" value="<?php echo $password ?>">
                
                <div id="buttons">
                    <input type="reset" name="reset" class="button" name="reset" value="Clear" style="background-color: indianred;" onclick="{clearFields()}">
                    <input type="submit" name="submit" class="button" name="submit" value="Login" style="background-color: dodgerblue;">
                </div>
            </form>
            <br><br>
            <a href="register-user.php" style="color: red; text-decoration:none; margin:30px 0 20px 10px;">Don't have an account? Create one. Click here</a>
        </div>
    </body>
</html>


<?php 

if (isset($_POST["submit"])){
    
    if($emailErr == "" && $passwordErr == ""){
       
        $servername = "localhost";
        $username = "root";
        $dbpassword = "";
        $dbname = "slmoto";
        
        // Create connection
        $conn = new mysqli($servername,$username,$dbpassword,$dbname);
        
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: ". $conn->connect_error);
        }

        $sql = "SELECT client_id, first_name FROM clients WHERE email='{$email}' AND `password`='{$password}';";

        $result = $conn->query($sql);

        $id = $first_name = "";

        if($result->num_rows == 1) {
            // output data of each row
            while($row = $result->fetch_assoc()){
                $id = $row["client_id"];
                $first_name = $row["first_name"];
            }
            // echo "<script> window.alert('Log in successfull'); </script>";
            $_SESSION["user_id"] = $id;
            $_SESSION["user_name"] = $first_name;
            $post_id = $_SESSION["return_to"];
            if ($post_id != 0){
                $returnTo = "index.php?page=view-post&id=" . $post_id;
                header("Location:" . $returnTo);
            } else {
                header("Location:all-vehicles.php");
            }



        } else {
            $emailErr = "Invalid email or password. Please try again.";
            $email = $password = "";
        }

        // if ($conn->query($sql) != NULL) {
        //     echo "Login successful";

        //    // header("Location:../login-user/login-user.php");
        // } else {
        //     echo "Error" . $sql . "<br>" . $conn->error;
        // }
        $conn->close();
    }
}

echo "<script> if(window.history.replaceState) {
    window.history.replaceState(null,null,window.location.href);
}</script>";

?>