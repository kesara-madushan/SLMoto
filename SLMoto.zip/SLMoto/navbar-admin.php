<!DOCTYPE html>
<html>
    <head>
    <link rel="stylesheet" href="./css/home.css">
    </head>

    <body>
    
        <div class="topnav">
            <a class="active" href="home-admin.php" >Home</a>
            <a href="index.php?page=all-vehicles-admin">All Vehicles</a>
            <a href="#">Client Requests</a>
            <a href="#">Reserved Vehicles</a>
            <a href="#Contact">Contact</a>
            <a href="#about">About</a>
            <p style="color: white;">SLMoto</p>
        </div>

    </body>
</html>